"""silrod-ui - Shared UI templates and static assets for silrod suite."""

import os

from jinja2 import ChoiceLoader, FileSystemLoader

__version__ = "0.2.1"


def get_static_dir() -> str:
    """Return the absolute path to silrod_ui static assets directory.

    Apps should mount this directory at /static/silrod/ in their FastAPI app:

        from silrod_ui import get_static_dir
        from fastapi.staticfiles import StaticFiles

        app.mount("/static/silrod", StaticFiles(directory=get_static_dir()), name="silrod-static")

    CSS is then available at /static/silrod/css/silrod.css
    """
    return os.path.join(os.path.dirname(__file__), "static")


def get_templates_dir() -> str:
    """Return the absolute path to silrod_ui templates directory.

    Apps can use this to configure Jinja2Templates to also search silrod-core templates.
    """
    return os.path.join(os.path.dirname(__file__), "templates")


def configure_template_loader(templates, app_templates_dir: str) -> None:
    """Make an app load local templates first, then shared silrod templates."""
    templates.env.loader = ChoiceLoader(
        [
            FileSystemLoader(app_templates_dir),
            FileSystemLoader(get_templates_dir()),
        ]
    )
