"""silrod-ui - Shared UI templates and static assets for silrod suite."""

import os

from jinja2 import ChoiceLoader, FileSystemLoader

__version__ = "0.2.1"


def get_static_dir() -> str:
    """Return the absolute path to silrod_ui static assets directory.

    Apps should mount this directory at /static/silrod/ in their FastAPI app:

        from silrod_ui import get_static_dir
        from fastapi.staticfiles import StaticFiles

        app.mount("/static/silrod", StaticFiles(directory=get_static_dir()), name="silrod-static")

    CSS is then available at /static/silrod/css/silrod.css
    """
    return os.path.join(os.path.dirname(__file__), "static")


def get_templates_dir() -> str:
    """Return the absolute path to silrod_ui templates directory.

    Apps can use this to configure Jinja2Templates to also search silrod-core templates.
    """
    return os.path.join(os.path.dirname(__file__), "templates")


def configure_template_loader(templates, app_templates_dir: str) -> None:
    """Make an app load local templates first, then shared silrod templates."""
    templates.env.loader = ChoiceLoader(
        [
            FileSystemLoader(app_templates_dir),
            FileSystemLoader(get_templates_dir()),
        ]
    )


def verify_shell_render(templates, shell_label: str) -> None:
    """Render the base template once at startup; raise if shell broken.
    
    Call from your app's lifespan startup. This catches the case where
    silrod-core isn't installed, the Jinja loader isn't configured, or
    the template path is wrong - all of which would otherwise silently
    serve a broken shell.
    
    Usage in your FastAPI app's main.py:
    
        from silrod_ui import configure_template_loader, verify_shell_render
        
        templates = Jinja2Templates(directory=str(template_dir))
        configure_template_loader(templates, str(template_dir))
        
        @app.on_event("startup")
        async def verify_shell():
            verify_shell_render(templates, "MyApp")
    
    Or with the new lifespan pattern:
    
        @asynccontextmanager
        async def lifespan(app: FastAPI):
            verify_shell_render(templates, "MyApp")
            yield
    """
    try:
        # Handle both FastAPI's Jinja2Templates and raw Jinja Environment
        from starlette.templating import Jinja2Templates
        if isinstance(templates, Jinja2Templates):
            html = templates.env.get_template("base.html").render(
                shell_label=shell_label,
                shell_nav='',
                shell_footer_label='',
                shell_version=''
            )
        else:
            html = templates.get_template("base.html").render(
                shell_label=shell_label,
                shell_nav='',
                shell_footer_label='',
                shell_version=''
            )
    except Exception as e:
        raise RuntimeError(
            f"Silrod shell base.html not found. Did you call configure_template_loader? "
            f"Original error: {e}"
        )
    expected = f"silrod | {shell_label}"
    if expected not in html:
        raise RuntimeError(
            f"Silrod shell failed to render. Expected '{expected}' in output. "
            f"Check silrod-core installation and template loader config."
        )
