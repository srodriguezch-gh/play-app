"""Portfolio Tax Calculations."""

# Tax Constants (2024 MFJ)
FEDERAL_BRACKETS_MFJ = [
    (23200, 0.10),
    (94300, 0.12),
    (201050, 0.22),
    (383900, 0.24),
    (487450, 0.32),
    (731200, 0.35),
    (float("inf"), 0.37),
]
STANDARD_DEDUCTION_MFJ = 29200
LTCG_BRACKETS_MFJ = [
    (94050, 0.0),
    (583750, 0.15),
    (float("inf"), 0.20),
]

def calculate_progressive_tax(income: float, brackets: list[tuple[float, float]], standard_deduction: float = 0.0) -> float:
    """Calculate progressive tax based on brackets."""
    taxable_income = max(0.0, income - standard_deduction)
    tax = 0.0
    prev_limit = 0.0
    for limit, rate in brackets:
        bracket_income = min(taxable_income, limit) - prev_limit
        if bracket_income <= 0:
            break
        tax += bracket_income * rate
        prev_limit = limit
    return tax

def calculate_ltcg_tax(ordinary_taxable_income: float, ltcg_amount: float, ltcg_brackets: list[tuple[float, float]]) -> float:
    """Calculate Long Term Capital Gains tax."""
    tax = 0.0
    total_income = ordinary_taxable_income + ltcg_amount
    
    prev_limit = 0.0
    for limit, rate in ltcg_brackets:
        # Intersection of [ordinary_taxable_income, total_income] and [prev_limit, limit]
        overlap_min = max(ordinary_taxable_income, prev_limit)
        overlap_max = min(total_income, limit)
        
        if overlap_max > overlap_min:
            tax += (overlap_max - overlap_min) * rate
            
        prev_limit = limit
        if total_income <= limit:
            break
    return tax
