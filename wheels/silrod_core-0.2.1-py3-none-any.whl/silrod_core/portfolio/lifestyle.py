"""Lifestyle and Arbitrage Calculations."""

from datetime import date
from typing import Any, Optional, cast

COLA_DB = {
    "Tampa, FL": {
        "index": 1.0,
        "emoji": "🇺🇸",
        "desc": "Baseline (High Cost)",
        "details": "Housing and insurance are primary drivers. 15% above US avg.",
    },
    "Nicaragua": {
        "index": 0.45,
        "emoji": "🇳🇮",
        "desc": "Maximum Arbitrage",
        "details": "Domestic labor & services are ~80% cheaper. Imported goods retain US prices.",
    },
    "Mexico City, MX": {
        "index": 0.60,
        "emoji": "🇲🇽",
        "desc": "Cosmopolitan Value",
        "details": "High culture at 60% cost. Rent is ~50% of Tampa. Food is 40% cheaper.",
    },
    "Todi, IT": {
        "index": 0.68,
        "emoji": "🇮🇹",
        "desc": "Umbrian Value",
        "details": "Quiet Italian hilltop living. 32% cheaper than Tampa. Excellent food and wine costs.",
    },
    "Lisbon, PT": {
        "index": 0.75,
        "emoji": "🇵🇹",
        "desc": "Euro-Zone Best",
        "details": "25% cheaper than Tampa. Healthcare is significantly cheaper; energy is higher.",
    },
    "Custom": {
        "index": 1.0,
        "emoji": "🌍",
        "desc": "User Defined",
        "details": "Manual adjustment.",
    },
}

LIFESTYLE_TIERS = {
    "LeanFIRE": 60000,
    "ChubbyFIRE": 100000,
    "FatFIRE": 150000,
    "ObeseFIRE": 300000,
}

BIRTH_DATE = date(1982, 10, 6)

def calculate_age(birth_date: date = BIRTH_DATE) -> float:
    """Calculate fractional age."""
    today = date.today()
    age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
    next_birthday = date(
        today.year if (today.month, today.day) < (birth_date.month, birth_date.day) else today.year + 1,
        birth_date.month,
        birth_date.day,
    )
    days_to_birthday = (next_birthday - today).days
    fractional = 1.0 - (days_to_birthday / 365.25)
    return float(age) + (fractional if fractional < 1.0 else 0.0)

def calculate_lifestyle_arbitrage(base_spend: float, location: str, cola_index: Optional[float] = None) -> dict[str, Any]:
    """Calculate spend adjusted for geographic location."""
    data = COLA_DB.get(location, COLA_DB["Custom"])
    idx = cola_index if (location == "Custom" and cola_index is not None) else cast(float, data["index"])
    idx = max(idx, 0.1)
    adjusted_spend = base_spend * idx
    return {
        "location": location,
        "index": idx,
        "adjusted_spend": adjusted_spend,
        "purchasing_power": 1.0 / idx,
        "savings_rate_boost": (base_spend - adjusted_spend),
        "details": data["details"],
    }
