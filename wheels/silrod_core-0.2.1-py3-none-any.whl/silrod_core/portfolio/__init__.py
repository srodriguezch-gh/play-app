"""Portfolio math and classification for the Silrod Homelab suite."""

from silrod_core.portfolio.tax import (
    FEDERAL_BRACKETS_MFJ,
    STANDARD_DEDUCTION_MFJ,
    LTCG_BRACKETS_MFJ,
    calculate_progressive_tax,
    calculate_ltcg_tax,
)
from silrod_core.portfolio.barbell import (
    AssetClass,
    DOMESTIC_EQUIVS,
    INTL_EQUIVS,
    CASH_EQUIVS,
    ALTERNATIVE_CRYPTO,
    ALTERNATIVE_REAL_ESTATE,
    TICKER_MAP,
    STATIC_ASSETS,
    classify_asset,
)
from silrod_core.portfolio.lifestyle import (
    COLA_DB,
    LIFESTYLE_TIERS,
    BIRTH_DATE,
    calculate_age,
    calculate_lifestyle_arbitrage,
)
from silrod_core.portfolio.sepp import (
    calc_72t_rmd,
    calc_72t_amortization,
    calculate_sepp_bridge_analysis,
)
from silrod_core.portfolio.net_worth import (
    calculate_bridge_health,
    get_milestones,
    calculate_fire_metrics,
)

__all__ = [
    "FEDERAL_BRACKETS_MFJ",
    "STANDARD_DEDUCTION_MFJ",
    "LTCG_BRACKETS_MFJ",
    "calculate_progressive_tax",
    "calculate_ltcg_tax",
    "AssetClass",
    "DOMESTIC_EQUIVS",
    "INTL_EQUIVS",
    "CASH_EQUIVS",
    "ALTERNATIVE_CRYPTO",
    "ALTERNATIVE_REAL_ESTATE",
    "TICKER_MAP",
    "STATIC_ASSETS",
    "classify_asset",
    "COLA_DB",
    "LIFESTYLE_TIERS",
    "BIRTH_DATE",
    "calculate_age",
    "calculate_lifestyle_arbitrage",
    "calc_72t_rmd",
    "calc_72t_amortization",
    "calculate_sepp_bridge_analysis",
    "calculate_bridge_health",
    "get_milestones",
    "calculate_fire_metrics",
]
