"""Barbell Tier Classification."""

from enum import Enum

class AssetClass(str, Enum):
    LAYER_1_EQUITY_CORE = "layer_1_equity_core"
    LAYER_2_FIXED_INCOME_BUFFER = "layer_2_fixed_income_buffer"
    LAYER_3_REAL_ESTATE_FLOOR = "layer_3_real_estate_floor"

# Asset Classification Matrix - Per Technical Spec
# US Domestic Equivalents (index funds, single stocks, active funds)
DOMESTIC_EQUIVS = [
    # Core index funds
    "VTI", "VOO", "VTSAX", "SPY", "ITOT", "SWTSX", "FXAIX", "VSMPX",
    # Fidelity funds
    "FTMJC", "FDGRX", "FDSSX", "FMAGX", "FLCSX", "FVDFX", "FSMAX", "FSPGX",
    # Active funds & ETFs
    "QUAL", "USMV",
    # ETFs and single stocks
    "FBGRX", "IJR", "IJH", "ONEQ", "ORCL", "VUG",
    # Fidelity annuity sub-funds (no live ticker, map to US equity)
    "FMNDC", "FLOLC",
]
# International Equivalents
INTL_EQUIVS = [
    # Core international
    "VXUS", "VEA", "VTIAX", "IXUS",
    # Fidelity international funds
    "FSPSX", "FPADX", "FEMKX", "DFAE", "FZAJX", "FISMX",
    "FIVA", "FIVLX", "EFV", "FNDE", "FOSFX",
]
# Fixed income / Cash equivalents (T-Bills, money market)
CASH_EQUIVS = ["CASH", "MONEY MARKET", "912797TA5", "912797UA3", "912797TS6", "912797TJ6"]
# Alternative assets (illiquid, excluded from 80/20 rebalancing)
ALTERNATIVE_CRYPTO = ["BTC-USD", "CRYPTO", "BITCOIN"]
ALTERNATIVE_REAL_ESTATE = ["Santa Teresa Farm", "Veracruz Farm"]

TICKER_MAP = {"FUND": "FXAIX", "VANGUARD TOTAL STK MARKET - I+": "VSMPX"}
STATIC_ASSETS = ["Santa Teresa Farm", "Veracruz Farm"]

def classify_asset(symbol: str, asset_type: str, institution: str = "") -> str:
    """Map a holding to its Barbell Tier.
    
    Returns: 'layer_1_equity_core', 'layer_2_fixed_income_buffer', or 'layer_3_real_estate_floor'
    """
    sym = symbol.upper().strip() if symbol else ""
    
    # Layer 2 — Fixed Income Buffer
    if asset_type in {"cash", "fixed_income"}:
        return AssetClass.LAYER_2_FIXED_INCOME_BUFFER.value
    if sym in {"SPAXX", "FDRXX", "FZFXX", "SGOV", "BIL", "SHY", "IEF", "SHV"}:
        return AssetClass.LAYER_2_FIXED_INCOME_BUFFER.value
    if sym in CASH_EQUIVS:
        return AssetClass.LAYER_2_FIXED_INCOME_BUFFER.value
    
    # Layer 3 — Real Estate Floor
    if asset_type == "static" or sym in ALTERNATIVE_REAL_ESTATE:
        return AssetClass.LAYER_3_REAL_ESTATE_FLOOR.value
    if "estate" in (institution + " " + sym).lower() or "farm" in (institution + " " + sym).lower():
        return AssetClass.LAYER_3_REAL_ESTATE_FLOOR.value
    
    # Layer 1 — Equity Core (default)
    return AssetClass.LAYER_1_EQUITY_CORE.value
