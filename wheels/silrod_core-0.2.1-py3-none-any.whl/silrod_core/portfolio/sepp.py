"""SEPP (72t) Calculations."""

def calc_72t_rmd(balance: float, rmd_factor: float) -> float:
    """Calculate 72t payment using the RMD method."""
    if balance <= 0 or rmd_factor <= 0:
        return 0.0
    return balance / rmd_factor

def calc_72t_amortization(initial_balance: float, period_years: float, interest_rate: float = 0.05) -> float:
    """Calculate 72t payment using the Amortization method."""
    if initial_balance <= 0 or period_years <= 0:
        return 0.0
    
    n = period_years * 12
    r = interest_rate / 12
    
    if r == 0:
        return initial_balance / period_years
        
    payment = (initial_balance * r) / (1 - (1 + r) ** (-n))
    return payment * 12

def calculate_sepp_bridge_analysis(sepp_annual: float, monthly_goal: float, ret_balance: float) -> dict:
    """Analyze the gap between SEPP income and spending goals."""
    sepp_m = sepp_annual / 12
    gap = sepp_m - monthly_goal
    rate = (sepp_annual / ret_balance) * 100 if ret_balance > 0 else 0
    flags = ["WARNING: SEPP exceeds 4% rate, increasing SORR Risk."] if rate > 4.0 else []
    return {
        "sepp_income_monthly": sepp_m,
        "monthly_expense_goal": monthly_goal,
        "gap_coverage_monthly": gap,
        "gap_coverage_percentage": (sepp_m / monthly_goal * 100) if monthly_goal > 0 else 0,
        "risk_flags": flags,
    }
