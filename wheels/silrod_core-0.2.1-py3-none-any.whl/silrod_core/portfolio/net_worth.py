"""Net Worth and Bridge Health Calculations."""

from datetime import datetime
from typing import Optional

def calculate_bridge_health(bridge_assets: float, annual_spend: float, target_age: float) -> dict:
    """Calculate the health of the bridge fund (pre-59.5 liquidity)."""
    needed = annual_spend * (59.5 - target_age)
    return {
        "bridge_assets": bridge_assets,
        "total_needed": needed,
        "health_pct": (bridge_assets / needed * 100) if needed > 0 else 100.0,
        "years_covered": bridge_assets / annual_spend if annual_spend > 0 else 0.0,
    }

def get_milestones(
    current_age: float,
    total_nw: float,
    liquid_nw: float,
    target_age: float,
    target_nw: float,
    annual_spend: float = 150000.0,
    bridge_fund_balance: float = 0.0,
    geo_location: str = "Tampa",
    age_to_fi: float = 0.0,
) -> list[dict]:
    """Generate a list of financial and lifestyle milestones."""
    ms = [
        {"age": 43, "label": "The 'Nuc' Foundation", "desc": "Bridge Account covers 2 years of expenses."},
        {"age": 45.5, "label": "SORR Safety Check", "desc": "Ensure Bridge Fund has 3 years of expenses."},
        {"age": 48.0, "label": "The College Bridge", "desc": "Mateo & Emma education impact check."},
        {"age": 50, "label": "IRS Catch-Up Gateway", "desc": "Eligible for extra 401(k) contributions."},
        {"age": 52.0, "label": "Geo-Arbitrage Trigger", "desc": "Decision node. Tampa target +$500k."},
        {"age": 55, "label": "Rule of 55 Access", "desc": "Penalty-free 401(k) access."},
        {"age": 59.5, "label": "Full Liquidity", "desc": "All IRAs/401(k)s unlocked."},
        {"age": 62, "label": "Social Security Floor", "desc": "Early SS eligibility."},
    ]
    if age_to_fi > 0:
        ms.append({"age": round(age_to_fi, 1), "label": "Projected FI", "desc": "Mathematically free."})

    for m in ms:
        m["years_to"] = m["age"] - current_age
        if m["age"] == 45.5:
            safe = bridge_fund_balance >= (annual_spend * 3)
            m["status"] = "Reached" if safe else "Warning"
            m["desc"] = "3 Years secured." if safe else f"Shortfall! Target: ${annual_spend * 3:,.0f}"
        elif m["age"] == 52.0:
            target_inc = 500000 if "Tampa" in geo_location else 0
            m["desc"] = f"{geo_location} selected. Target adj: +${target_inc:,.0f}"
            m["status"] = "Reached" if m["years_to"] <= 0 else "Upcoming"
        else:
            m["status"] = "Reached" if m["years_to"] <= 0 else "Upcoming"
    return sorted(ms, key=lambda x: x["age"])

def calculate_fire_metrics(
    age: float,
    target_age: float,
    total_nw: float,
    liquid_nw: float,
    base_spend: float,
    adjusted_spend: float,
    swr_mode: str = "Total Portfolio"
) -> dict:
    """Calculate core FIRE metrics and progress."""
    import math
    
    t_nw = adjusted_spend / 0.04
    swr_base = total_nw if swr_mode == "Total Portfolio" else liquid_nw
    progress = (swr_base / t_nw * 100) if t_nw > 0 else 0
    
    # Simple growth projection (7%)
    try:
        if total_nw > 0 and t_nw > total_nw:
            age_to_fi = age + (math.log(t_nw / total_nw) / math.log(1.07))
        else:
            age_to_fi = age
    except (ValueError, ZeroDivisionError):
        age_to_fi = age

    return {
        "adjusted_annual_spend": adjusted_spend,
        "target_fire_number": t_nw,
        "progress_to_fire": min(100.0, progress),
        "time_to_freedom_str": f"{int(target_age - age)} years" if target_age > age else "REACHED",
        "age_to_fi": age_to_fi,
        "age_to_freedom": target_age,
    }
