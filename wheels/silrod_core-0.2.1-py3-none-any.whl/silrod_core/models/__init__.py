"""
Shared SQLAlchemy mixins for all silrod models.

Usage:
    from silrod_core.db import Base
    from silrod_core.models import TimestampMixin, UUIDPKMixin

    class User(TimestampMixin, Base):
        __tablename__ = "users"
        ...
"""

from datetime import datetime, timezone
from uuid import uuid4

from sqlalchemy import Column, DateTime
from sqlalchemy.dialects.postgresql import UUID

from silrod_core.models.health_check import HealthCheckResult

__all__ = ["TimestampMixin", "UUIDPKMixin", "HealthCheckResult"]


class TimestampMixin:
    """Adds ``created_at`` and ``updated_at`` datetime columns."""

    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )


class UUIDPKMixin:
    """Adds a UUID primary key ``id`` with auto-generated uuid4."""

    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4,
    )
