from datetime import datetime, timezone

from sqlalchemy import Boolean, Column, DateTime, Float, Integer, JSON, String

from silrod_core.db import Base


class HealthCheckResult(Base):
    __tablename__ = "health_checks"
    id = Column(Integer, primary_key=True)
    endpoint_name = Column(String)
    endpoint_url = Column(String)
    probe_type = Column(String)
    status = Column(String)
    response_time_ms = Column(Float)
    status_code = Column(Integer)
    response_body = Column(String)
    error = Column(String)
    conditions_passed = Column(Boolean)
    conditions_details = Column(JSON)
    timestamp = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
