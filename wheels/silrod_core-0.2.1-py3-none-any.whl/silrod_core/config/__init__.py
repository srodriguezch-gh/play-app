"""
Vault-backed settings for the silrod app suite.

Usage:
    from silrod_core.config import SilrodSettings

    class AppSettings(SilrodSettings):
        app_name: str = "my-app"
        app_port: int = 8000

    settings = AppSettings()  # loads env + vault secrets
"""

import logging
import sys
from pathlib import Path
from typing import Optional

from pydantic_settings import BaseSettings

logger = logging.getLogger(__name__)

# Lazy-import vault to avoid making it a hard dependency
VAULT_AVAILABLE = False
try:
    sys.path.append(str(Path.home() / "scripts"))
    from vault_client import get_vault  # type: ignore[import-untyped]

    VAULT_AVAILABLE = True
except ImportError:
    pass


class SilrodSettings(BaseSettings):
    """Base settings class with vault integration for the homelab."""

    # App basics
    app_name: str = "silrod-app"
    app_version: str = "0.1.0"
    debug: bool = False

    # Postgres
    postgres_host: str = "localhost"
    postgres_port: int = 5432
    postgres_user: str = "postgres_admin"
    postgres_password: str = ""
    postgres_db: str = "silrod"
    postgres_schema: str = "public"

    # Vault / infra
    bosgame_ip: str = "192.168.5.98"

    @property
    def postgres_url(self) -> str:
        pw = self.postgres_password if self.postgres_password else "***"
        return f"postgresql://{self.postgres_user}:{pw}@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}"

    @property
    def postgres_async_url(self) -> str:
        return f"postgresql+asyncpg://{self.postgres_user}:{self.postgres_password}@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        extra = "ignore"

    def model_post_init(self, __context) -> None:
        super().model_post_init(__context)
        self._load_secrets()

    def _load_secrets(self) -> None:
        """Replace localhost with BOSGAME_IP and fetch missing secrets from vault."""
        # Always auto-detect postgres_host when it's at default "localhost"
        if self.postgres_host == "localhost":
            import os
            in_docker = os.path.exists("/.dockerenv") or os.environ.get("SILROD_DOCKER_MODE", "").lower() in ("1", "true")
            if in_docker:
                self.postgres_host = "postgres"
            else:
                self.postgres_host = self.bosgame_ip

        if not VAULT_AVAILABLE:
            logger.info("vault_client not available, running with env-only settings")
            return

        vault = get_vault()

        # Fetch password from vault if not set via env
        if not self.postgres_password:
            self.postgres_password = vault.get_secret("WATCHDOG_PG_PASSWORD") or "health_password"
