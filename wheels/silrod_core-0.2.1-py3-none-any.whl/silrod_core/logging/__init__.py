"""
Structured JSON logging for the silrod app suite.

Usage:
    from silrod_core.logging import setup_logging
    setup_logging(level="INFO")

    # With app name
    from silrod_core.logging import setup_logging, get_logger
    setup_logging(level="INFO", app_name="my-app", json_output=True)
    logger = get_logger("my-app")

    # LOG_LEVEL env var is automatically read if not provided
    # Extra fields (request_id, user_id, endpoint) can be added per-logger:
    logger = get_logger("my-app", extra={"request_id": "abc123"})

All log records go to stderr as JSON lines for production, or plain text for local dev.
"""

import json
import logging
import os
import sys
from datetime import datetime, timezone
from typing import Optional


class JSONFormatter(logging.Formatter):
    """Format log records as JSON lines."""

    def __init__(self, app_name: Optional[str] = None):
        super().__init__()
        self.app_name = app_name

    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if self.app_name:
            payload["app"] = self.app_name
        for key in ("request_id", "user_id", "endpoint"):
            if hasattr(record, key):
                payload[key] = getattr(record, key)
        if record.exc_info and record.exc_info[0]:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload)


def _get_log_level(env_var: str, default: str) -> str:
    """Read log level from environment variable."""
    return os.environ.get(env_var, default).upper()


def setup_logging(
    level: Optional[str] = None,
    json_output: Optional[bool] = None,
    name: str = "silrod",
    app_name: Optional[str] = None,
) -> logging.Logger:
    """Configure the root logger.

    Args:
        level: Log level string (DEBUG, INFO, WARNING, ERROR). Reads LOG_LEVEL env var if not set.
        json_output: If True, emit JSON lines to stderr. If False, plain text. Reads LOG_JSON env var if not set.
        name: Logger name (used to get a specific logger instance).
        app_name: Application identifier emitted in every JSON log line as "app" field.
            Auto-detected from SILROD_APP_NAME env var if not provided.

    Returns:
        The configured logger instance.
    """
    _level = level or _get_log_level("LOG_LEVEL", "INFO")
    _json = json_output if json_output is not None else os.environ.get("LOG_JSON", "1") != "0"
    _app_name = app_name or os.environ.get("SILROD_APP_NAME")

    root = logging.getLogger()
    root.setLevel(getattr(logging, _level, logging.INFO))

    for handler in root.handlers[:]:
        root.removeHandler(handler)

    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(getattr(logging, _level, logging.INFO))

    if _json:
        handler.setFormatter(JSONFormatter(app_name=_app_name))
    else:
        handler.setFormatter(
            logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
        )

    root.addHandler(handler)
    return logging.getLogger(name)


def get_logger(name: str, level: Optional[str] = None, extra: Optional[dict] = None) -> logging.Logger:
    """Get a logger with optional extra fields and LOG_LEVEL override.

    Args:
        name: Logger name (usually __name__).
        level: Override log level. Defaults to LOG_LEVEL env var.
        extra: Dict of extra fields to attach to every log record (e.g. request_id, user_id, endpoint).

    Returns:
        A configured logger instance.
    """
    _level = level or _get_log_level("LOG_LEVEL", "INFO")
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, _level, logging.INFO))
    if extra:
        old_factory = logging.getLogRecordFactory()
        def record_factory(*args, **kwargs):
            record = old_factory(*args, **kwargs)
            for k, v in extra.items():
                setattr(record, k, v)
            return record
        logging.setLogRecordFactory(record_factory)
    return logger
