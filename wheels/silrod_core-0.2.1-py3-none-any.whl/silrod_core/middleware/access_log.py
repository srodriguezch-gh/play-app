"""
Structured access log middleware for the silrod app suite.

Logs every HTTP request as a JSON line with:
- timestamp (ISO 8601 UTC)
- method, path, status_code
- duration_ms, ip, user_agent
- request_id (generated if not provided via X-Request-ID header)
- app_name (from constructor)

Usage:
    from silrod_core.middleware.access_log import AccessLogMiddleware

    app.add_middleware(
        AccessLogMiddleware,
        app_name="my-app",
        log_level="INFO",
        exclude_paths=["/health", "/ready", "/docs", "/openapi.json", "/redoc"],
    )
"""

import logging
import time
import uuid
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

logger = logging.getLogger("access")


class AccessLogMiddleware(BaseHTTPMiddleware):
    """Middleware that logs every HTTP request as a structured JSON line."""

    def __init__(
        self,
        app,
        app_name: str = "silrod",
        log_level: str = "INFO",
        exclude_paths: list[str] = None,
    ):
        super().__init__(app)
        self.app_name = app_name
        self.log_level = getattr(logging, log_level.upper(), logging.INFO)
        self.exclude_paths = exclude_paths or ["/health", "/ready", "/docs", "/openapi.json", "/redoc"]

    async def dispatch(self, request: Request, call_next) -> Response:
        if request.url.path in self.exclude_paths:
            return await call_next(request)

        request_id = request.headers.get("x-request-id", str(uuid.uuid4()))
        start_time = time.perf_counter()

        response = await call_next(request)

        duration_ms = (time.perf_counter() - start_time) * 1000

        log_data = {
            "timestamp": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
            "level": "INFO",
            "logger": "access",
            "app": self.app_name,
            "method": request.method,
            "path": request.url.path,
            "status": response.status_code,
            "duration_ms": round(duration_ms, 2),
            "ip": request.client.host if request.client else "-",
            "user_agent": request.headers.get("user-agent", "-"),
            "request_id": request_id,
        }

        if response.status_code >= 500:
            log_data["level"] = "ERROR"
        elif response.status_code >= 400:
            log_data["level"] = "WARNING"

        logger.log(
            self.log_level,
            f'{log_data["method"]} {log_data["path"]} {log_data["status"]} {log_data["duration_ms"]}ms',
            extra=log_data,
        )

        response.headers["X-Request-ID"] = request_id
        return response