import asyncio
import logging
import time
import uuid
from typing import Optional

import httpx
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

logger = logging.getLogger(__name__)


class TrackingMiddleware(BaseHTTPMiddleware):
    """Middleware to automatically track all API calls to analytics service."""

    def __init__(self, app: ASGIApp, app_id: str, analytics_url: str, enabled: bool = True):
        super().__init__(app)
        self.app_id = app_id
        self.analytics_url = analytics_url
        self.enabled = enabled

    async def dispatch(self, request: Request, call_next) -> Response:
        """Process request and track event."""
        if not self.enabled:
            return await call_next(request)

        # Skip health/ready checks
        if request.url.path in ["/health", "/ready", "/docs", "/openapi.json", "/redoc"]:
            return await call_next(request)

        start_time = time.time()
        session_id = request.headers.get("x-session-id", str(uuid.uuid4()))
        user_id = request.headers.get("x-user-id")

        try:
            response = await call_next(request)
            duration_ms = int((time.time() - start_time) * 1000)

            # Track event in background
            asyncio.create_task(
                self._track_event(
                    endpoint=request.url.path,
                    method=request.method,
                    status_code=response.status_code,
                    duration_ms=duration_ms,
                    session_id=session_id,
                    user_id=user_id,
                )
            )

            return response

        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            logger.error(f"Error in request: {e}")

            # Still track the error
            asyncio.create_task(
                self._track_event(
                    endpoint=request.url.path,
                    method=request.method,
                    status_code=500,
                    duration_ms=duration_ms,
                    session_id=session_id,
                    user_id=user_id,
                )
            )
            raise

    async def _track_event(
        self,
        endpoint: str,
        method: str,
        status_code: int,
        duration_ms: int,
        session_id: str,
        user_id: Optional[str] = None,
    ):
        """Track event to analytics service."""
        try:
            async with httpx.AsyncClient(timeout=2.0) as client:
                await client.post(
                    f"{self.analytics_url}/api/v1/track",
                    json={
                        "app_id": self.app_id,
                        "event_type": "api_call",
                        "endpoint": endpoint,
                        "method": method,
                        "status_code": status_code,
                        "duration_ms": duration_ms,
                        "session_id": session_id,
                        "user_id": user_id,
                    },
                )
        except Exception as e:
            logger.warning(f"Failed to track event: {e}")
