from fastapi import Request
from fastapi.responses import JSONResponse, HTMLResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.status import HTTP_500_INTERNAL_SERVER_ERROR

# A simple HTML error template for non-API routes
HTML_ERROR_TEMPLATE = """<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Error</title><style>body{{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;display:flex;justify-content:center;align-items:center;min-height:100vh;margin:0;background-color:#f8f8f8;color:#333;text-align:center}}.container{{background-color:#fff;border-radius:8px;box-shadow:0 4px 6px rgba(0,0,0,0.1);padding:40px;max-width:500px;width:90%%}}h1{{color:#d32f2f;margin-bottom:20px}}p{{font-size:1.1em;line-height:1.6;margin-bottom:30px}}a{{color:#1976d2;text-decoration:none;font-weight:bold}}a:hover{{text-decoration:underline}}</style></head><body><div class="container"><h1>Error %(status_code)s</h1><p>%(detail)s</p><a href="/">Go to Homepage</a></div></body></html>"""

class SharedErrorHandlerMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        try:
            response = await call_next(request)
            return response
        except StarletteHTTPException as exc:
            return await self.handle_http_exception(request, exc)
        except Exception as exc:
            return await self.handle_general_exception(request, exc)

    async def handle_http_exception(self, request: Request, exc: StarletteHTTPException):
        status_code = exc.status_code
        detail = exc.detail

        if request.url.path.startswith("/api/"):
            return JSONResponse(
                status_code=status_code,
                content={"detail": detail}
            )
        else:
            return HTMLResponse(
                status_code=status_code,
                content=HTML_ERROR_TEMPLATE % {"status_code": status_code, "detail": detail}
            )

    async def handle_general_exception(self, request: Request, exc: Exception):
        status_code = HTTP_500_INTERNAL_SERVER_ERROR
        detail = "Internal Server Error"

        import traceback
        traceback.print_exc()

        if request.url.path.startswith("/api/"):
            return JSONResponse(
                status_code=status_code,
                content={"detail": detail}
            )
        else:
            return HTMLResponse(
                status_code=status_code,
                content=HTML_ERROR_TEMPLATE % {"status_code": status_code, "detail": detail}
            )
