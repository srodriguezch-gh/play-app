"""
Raw asyncpg connection pool management for services that don't use SQLAlchemy.

Usage:
    from silrod_core.db.asyncpg_pool import PoolManager

    pool = PoolManager()

    async def startup():
        await pool.init()

    async def query():
        async with pool.acquire() as conn:
            return await conn.fetch("SELECT * FROM ...")

    async def shutdown():
        await pool.close()
"""

import logging
from typing import Optional

import asyncpg

logger = logging.getLogger(__name__)


class PoolManager:
    """Manages an asyncpg connection pool with lazy initialization.

    Reads credentials from SilrodSettings at init time so vault integration
    is already resolved.
    """

    def __init__(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        database: Optional[str] = None,
        user: Optional[str] = None,
        password: Optional[str] = None,
        min_size: int = 1,
        max_size: int = 10,
    ):
        self._pool: Optional[asyncpg.Pool] = None
        self._host = host
        self._port = port
        self._database = database
        self._user = user
        self._password = password
        self._min_size = min_size
        self._max_size = max_size

    async def init(self) -> None:
        """Create the connection pool. Idempotent — safe to call multiple times."""
        if self._pool is not None:
            return

        # If no explicit params, try to load from SilrodSettings
        if self._host is None:
            try:
                from silrod_core.config import SilrodSettings

                s = SilrodSettings()
                self._host = s.postgres_host
                self._port = s.postgres_port
                self._database = s.postgres_db
                self._user = s.postgres_user
                self._password = s.postgres_password
            except Exception as exc:
                raise RuntimeError(
                    "PoolManager needs explicit params or silrod_core.config.SilrodSettings"
                ) from exc

        self._pool = await asyncpg.create_pool(
            host=self._host,
            port=self._port,
            database=self._database,
            user=self._user,
            password=self._password,
            min_size=self._min_size,
            max_size=self._max_size,
            statement_cache_size=0,
        )
        logger.info(
            "asyncpg pool created: %s@%s:%s/%s (min=%d, max=%d)",
            self._user,
            self._host,
            self._port,
            self._database,
            self._min_size,
            self._max_size,
        )

    @property
    def pool(self) -> asyncpg.Pool:
        """Return the underlying pool. Raises if not initialized."""
        if self._pool is None:
            raise RuntimeError("PoolManager not initialized — call init() first")
        return self._pool

    async def acquire(self) -> asyncpg.Connection:
        """Acquire a connection from the pool."""
        return await self.pool.acquire()

    async def close(self) -> None:
        """Close all connections in the pool."""
        if self._pool:
            await self._pool.close()
            self._pool = None
            logger.info("asyncpg pool closed")

    async def __aenter__(self):
        await self.init()
        return self

    async def __aexit__(self, *args):
        await self.close()
