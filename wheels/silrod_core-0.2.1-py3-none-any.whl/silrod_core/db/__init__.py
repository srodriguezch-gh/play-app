"""
Database session management — async Postgres engine + session factory.

Usage:
    from silrod_core.db import configure, get_db, init_db, Base

    # FastAPI app startup
    dm = configure("postgresql+asyncpg://user:pass@host/db", schema="brain")
    await init_db(Base)

    @app.get("/items")
    async def list_items(db: AsyncSession = Depends(get_db)):
        ...

    # Manual usage
    async with dm.session() as session:
        ...
"""

import logging
from typing import AsyncGenerator, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.pool import NullPool


class Base(DeclarativeBase):
    pass

logger = logging.getLogger(__name__)


class _DatabaseManager:
    """Manages an async Postgres engine + session factory.

    Thread-safe per connection string. Instantiate once at app startup.
    """

    def __init__(self, async_url: str, schema: str = "public", echo: bool = False):
        self.async_url = async_url
        self.schema = schema
        self.echo = echo
        self._engine = None
        self._session_maker = None
        self._base: Optional[DeclarativeBase] = None

    async def init(self, base: DeclarativeBase) -> None:
        """Initialize engine + session factory, create schema + tables."""
        if self._engine is not None:
            return

        self._base = base
        self._engine = create_async_engine(
            self.async_url,
            poolclass=NullPool,
            echo=self.echo,
        )
        self._session_maker = async_sessionmaker(
            self._engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

        async with self._engine.begin() as conn:
            if self.schema != "public":
                await conn.execute(text(f"CREATE SCHEMA IF NOT EXISTS {self.schema}"))
            await conn.run_sync(base.metadata.create_all)

        logger.info(
            "Postgres engine initialized (schema=%s, echo=%s)", self.schema, self.echo
        )

    async def session(self) -> AsyncGenerator[AsyncSession, None]:
        """Get an async session. Used as async generator for FastAPI Depends."""
        if self._session_maker is None:
            raise RuntimeError("DatabaseManager not initialized — call init() first")

        async with self._session_maker() as session:
            yield session

    async def close(self) -> None:
        """Dispose the engine."""
        if self._engine:
            await self._engine.dispose()
            self._engine = None
            self._session_maker = None
            logger.info("Postgres engine disposed")


# Public alias
DatabaseManager = _DatabaseManager

# Module-level state for the default instance (singleton pattern)
_default_manager: Optional[_DatabaseManager] = None


def configure(async_url: str, schema: str = "public", echo: bool = False) -> _DatabaseManager:
    """Configure the default DatabaseManager.

    Call once at app startup before using ``get_db``.
    """
    global _default_manager
    _default_manager = _DatabaseManager(async_url, schema, echo)
    return _default_manager


def get_manager() -> _DatabaseManager:
    """Return the configured default DatabaseManager."""
    if _default_manager is None:
        raise RuntimeError("DatabaseManager not configured — call silrod_core.db.configure()")
    return _default_manager


async def init_db(base: DeclarativeBase) -> None:
    """Initialize the default manager's engine + schema + tables."""
    await get_manager().init(base)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency: yield an async session from the default manager."""
    async for session in get_manager().session():
        yield session


__all__ = [
    "configure",
    "get_db",
    "init_db",
    "get_manager",
    "Base",
    "DatabaseManager",
]
