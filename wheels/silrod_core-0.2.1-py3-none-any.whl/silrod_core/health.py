"""
Standard health check router for all silrod apps.

Usage in FastAPI:
    from silrod_core.health import health_router

    app.include_router(health_router)

Provides:
    GET /health      — JSON {"status": "healthy"} (always returns 200)
    GET /ready       — JSON {"status": "ready"} (always returns 200)
    GET /healthz     — alias for /health (backward compat)
"""

from fastapi import APIRouter

health_router = router = APIRouter()


@router.get("/health")
@router.get("/healthz")
async def health():
    return {"status": "healthy"}


@router.get("/ready")
async def ready():
    return {"status": "ready"}