"""
silrod-core — Shared library for the silrod app suite.

Provides:
- silrod_core.db: Async Postgres engine + session factory + Base + mixins
- silrod_core.config: Pydantic BaseSettings with vault integration
- silrod_core.logging: Structured JSON logger setup (setup_logging, get_logger, JSONFormatter)
- silrod_core.middleware: TrackingMiddleware, AccessLogMiddleware, SharedErrorHandlerMiddleware
- silrod_core.models: TimestampMixin, UUIDPKMixin, HealthCheckResult
- silrod_core.cache: Redis connection manager (RedisManager, configure_redis, get_redis)
- silrod_core.health: Standard health router (health_router with /health, /healthz, /ready)
- silrod_ui: Shared HTML templates, CSS components, Chart.js config

Version: 0.2.3
"""

__version__ = "0.2.3"