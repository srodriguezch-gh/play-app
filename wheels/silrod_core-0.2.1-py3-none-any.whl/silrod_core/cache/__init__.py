"""
Redis connection manager for the silrod app suite.

Usage:
    from silrod_core.cache import RedisManager, get_redis

    redis = RedisManager(
        host="homelab-redis",
        port=6379,
        db=0,
        password=None,
        min_size=1,
        max_size=10,
    )
    await redis.init()

    # Or use singleton
    from silrod_core.cache import configure_redis, get_redis
    configure_redis("homelab-redis", 6379, db=0)
    redis = get_redis()

    async with redis.pool.acquire() as conn:
        await conn.set("key", "value")
        val = await conn.get("key")
"""

import logging
from typing import Optional

logger = logging.getLogger(__name__)


class RedisManager:
    """Async Redis connection pool manager."""

    def __init__(
        self,
        host: Optional[str] = None,
        port: int = 6379,
        db: int = 0,
        password: Optional[str] = None,
        min_size: int = 1,
        max_size: int = 10,
    ):
        self.host = host or "localhost"
        self.port = port
        self.db = db
        self.password = password
        self.min_size = min_size
        self.max_size = max_size
        self._pool = None

    async def init(self) -> None:
        """Initialize the Redis connection pool."""
        import redis.asyncio as redis

        self._pool = redis.ConnectionPool(
            host=self.host,
            port=self.port,
            db=self.db,
            password=self.password,
            max_connections=self.max_size,
            decode_responses=True,
        )
        logger.info(f"Redis pool initialized (host={self.host}, port={self.port}, db={self.db})")

    @property
    def pool(self):
        if self._pool is None:
            raise RuntimeError("Redis pool not initialized — call init() first")
        return self._pool

    async def acquire(self):
        """Acquire a connection from the pool (async context manager)."""
        return self.pool.acquire()

    async def close(self) -> None:
        """Close all connections in the pool."""
        if self._pool:
            await self._pool.disconnect()
            self._pool = None
            logger.info("Redis pool closed")

    async def __aenter__(self):
        await self.init()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()


# Module-level singleton
_default_manager: Optional[RedisManager] = None


def configure_redis(
    host: str = "homelab-redis",
    port: int = 6379,
    db: int = 0,
    password: Optional[str] = None,
    min_size: int = 1,
    max_size: int = 10,
) -> RedisManager:
    """Configure the default RedisManager (singleton)."""
    global _default_manager
    _default_manager = RedisManager(host=host, port=port, db=db, password=password, min_size=min_size, max_size=max_size)
    return _default_manager


def get_redis() -> RedisManager:
    """Return the configured default RedisManager."""
    if _default_manager is None:
        raise RuntimeError("RedisManager not configured — call configure_redis() first")
    return _default_manager